#include <stdio.h>
#include <string.h>
#include <time.h>
#include <stdlib.h>
#include <ctype.h>
#include "priorityqueue.h"
#include "fifoqueue.h"

#ifndef COMHAN_H_
# define COMHAN_H_

// Version information for the TechOS
#define VERSION_NUMBER "2.0"
#define AUTHORS "Logan Bland, John Clay, Jalen Wayt"
#define COMPLETION_DATE "09/28/2021"

// Command names within the TechOs
#define CMD_CDDATE "chdate"
#define CMD_DATE "date"
#define CMD_HELP "help"
#define CMD_QUIT "quit"
#define CMD_TIME "time"
#define CMD_VERSION "version"
#define CMD_CREATE_PCB "crprocess"
#define CMD_DELETE_PCB "delprocess"
#define CMD_BLOCK "block"
#define CMD_SETPRIORITY "setpr"
#define CMD_SUSPEND "suspend"
#define CMD_RESUME "resume"
#define CMD_UNBLOCK "unblock"
#define CMD_SHPCB "shpcb"
#define CMD_SHALLPCB "shallpcb"
#define CMD_SHOW_READY_PROCESSES "shready"
#define CMD_SHOW_BLOCKED_PROCESSES "shblocked"
//Input Names including the next line character
#define INPUT_CDDATE "chdate\n"
#define INPUT_DATE "date\n"
#define INPUT_HELP "help\n"
#define INPUT_QUIT "quit\n"
#define INPUT_TIME "time\n"
#define INPUT_VERSION "version\n"
#define INPUT_CREATE_PCB "crprocess\n"
#define INPUT_DELETE_PCB "delprocess\n"
#define INPUT_SETPRIORITY "setpr\n"
#define INPUT_SUSPEND "suspend\n"
#define INPUT_RESUME "resume\n"
#define INPUT_BLOCK "block\n"
#define INPUT_UNBLOCK "unblock\n"
#define INPUT_SHPCB "shpcb\n"
#define INPUT_SHALLPCB "shallpcb\n"
#define INPUT_SHOW_READY_PROCESSES "shready\n"
#define INPUT_SHOW_BLOCKED_PROCESSES "shblocked\n"

//Used to calculate the date difference if the user decides to change the date
/*typedef struct DateDifference{
    int numMonths;
    int numDays;
    int numYears;
}DateDifference;*/

//Function Prototypes
void COMHAN();
void Help(char* cmdName);
void Version();
void DisplayDate();
//char *getMonth(int month);
void ChangeDate(char *parameters);
//int checkMonth(int month, int day, int year);
//void calculateDateDifference();
void DisplayTime();
void TerminateTechOS();
//void printFile(char *fileName);
//void convertToLowercase(char *input);
void createPCB(char name[], char *class, char *priority);
void deletePCB(char *processName);
void block(char *processName);
void setPriority(char *processName, char *priority);
void suspend(char *processName);
void resume(char *processName);
void block(char *processName);
void unblock(char *processName);
void showPCB(char *processName);
void showAllPCB();
//char *getState(int s);
//char *getSuspendedStatus(int s);
//char *getClass(int val);
void ShowReadyProcesses();
void ShowBlockedProcesses();
//int isNumber(char *s);

#endif