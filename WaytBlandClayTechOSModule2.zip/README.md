# TechOS
TechOS is for the Operating Systems course at WVU Tech
